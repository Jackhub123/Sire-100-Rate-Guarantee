# Sire Landing (Vercel)
Static site with a single `index.html`. Mobile-friendly and ready for Vercel.

## Deploy
- **GitHub → Vercel:** Upload these files to a GitHub repo, then `New Project → Continue with GitHub` in Vercel.
- **CLI:** Install `npm i -g vercel`, then run `vercel --prod` in this folder.

## Customize
- Update the Typeform URL in the `<a class="btn">` links if you change it.
